"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(282);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
;// CONCATENATED MODULE: ./components/HeaderItem.js



function HeaderItem({
  title,
  Icon
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "flex flex-col items-center cursor-pointer group \r w-12 sm:w-20 hover:text-white",
    children: [/*#__PURE__*/jsx_runtime_.jsx(Icon, {
      className: "h-8 mb-1 group-hover:animate-bounce"
    }), /*#__PURE__*/jsx_runtime_.jsx("p", {
      className: "opacity-0 group-hover:opacity-100 \r tracking-widest",
      children: title
    })]
  });
}

/* harmony default export */ const components_HeaderItem = (HeaderItem);
// EXTERNAL MODULE: ./node_modules/@heroicons/react/outline/esm/index.js + 230 modules
var esm = __webpack_require__(49);
;// CONCATENATED MODULE: ./components/Header.js






function Header() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
    className: "flex flex-col sm:flex-row m-5 justify-between\r items-center h-auto",
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-grow justify-evenly max-w-2xl",
      children: [/*#__PURE__*/jsx_runtime_.jsx(components_HeaderItem, {
        title: "HOME",
        Icon: esm/* HomeIcon */.tvw
      }), /*#__PURE__*/jsx_runtime_.jsx(components_HeaderItem, {
        title: "TRENDING",
        Icon: esm/* LightningBoltIcon */.YGl
      }), /*#__PURE__*/jsx_runtime_.jsx(components_HeaderItem, {
        title: "VERIFIED",
        Icon: esm/* BadgeCheckIcon */.js$
      }), /*#__PURE__*/jsx_runtime_.jsx(components_HeaderItem, {
        title: "COLLECTIONS",
        Icon: esm/* CollectionIcon */.wZP
      }), /*#__PURE__*/jsx_runtime_.jsx(components_HeaderItem, {
        title: "SEARCH",
        Icon: esm/* SearchIcon */.W1M
      }), /*#__PURE__*/jsx_runtime_.jsx(components_HeaderItem, {
        title: "ACCOUNT",
        Icon: esm/* UserIcon */.tBG
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
      className: "object-contain",
      src: "https://links.papareact.com/ua6",
      width: 200,
      height: 100
    })]
  });
}

/* harmony default export */ const components_Header = (Header);
;// CONCATENATED MODULE: ./utils/requests.js
const API_KEY = process.env.API_KEY;
/* harmony default export */ const requests = ({
  fetchTrending: {
    title: "Trending",
    url: `/trending/all/week?api_key=${API_KEY}&language=en-US`
  },
  fetchTopRated: {
    title: "Top Rated",
    url: `/movie/top_rated?api_key=${API_KEY}&language=en-US`
  },
  fetchActionMovies: {
    title: "Action",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=28`
  },
  fetcComedyMovies: {
    title: "Comedy",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=35`
  },
  fetchHorrorMovies: {
    title: "Horror",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=27`
  },
  fetchRomanceMovies: {
    title: "Romance",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=10749`
  },
  fetchMystery: {
    title: "Mystery",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=9648`
  },
  fetchSciFi: {
    title: "Sci-Fi",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=878`
  },
  fetchWestern: {
    title: "Western",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=37`
  },
  fetchAnimation: {
    title: "Animation",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=16`
  },
  fetchTV: {
    title: "TV Movie",
    url: `/discover/movie?api_key=${API_KEY}&with_genres=10770`
  }
});
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
;// CONCATENATED MODULE: ./components/Nav.js





function Nav() {
  const router = (0,router_namespaceObject.useRouter)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
    className: "relative",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex px-10 sm:px-20 text-2xl whitespace-nowrap space-x-10 sm:space-x-20 overflow-x-scroll scrollbar-hide",
      children: Object.entries(requests).map(([key, {
        title,
        url
      }]) => /*#__PURE__*/jsx_runtime_.jsx("h2", {
        onClick: () => router.push(`/?genre=${key}`),
        className: "last:ppr-24 cursor-pointer transistion duration-100 transform hover:scale-125 hover:text-white active-text active:text-red-500",
        children: title
      }, key))
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "absolute top-0 right-0 bg-gradient-to-l from-[#06202A] h-10 w-1/12"
    })]
  });
}

/* harmony default export */ const components_Nav = (Nav);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(297);
;// CONCATENATED MODULE: ./components/Thumbnail.js





const Thumbnail = /*#__PURE__*/(0,external_react_.forwardRef)(({
  result
}, ref) => {
  const BASE_URL = "https://image.tmdb.org/t/p/original/";
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    ref: ref,
    className: "p-2 group cursor-pointer transition duration-200 ease-in transform sm:hover:scale-105 hover:z-50",
    children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
      layout: "responsive",
      src: `${BASE_URL}${result.backdrop_path || result.poster_path}` || `${BASE_URL}${result.poster_path}`,
      height: 810,
      width: 1440
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "p-2",
      children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "truncate max-w-md",
        children: result.overview
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "mt-1 text-2xl text-white transition=all duration-100 ease-in-out group-hover:font-bold",
        children: result.title || result.original_name
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
        className: "flex items-center opacity-0 group-hover:opacity-100",
        children: [result.release_date || result.first_air_date, " \u2022", " ", /*#__PURE__*/jsx_runtime_.jsx(esm/* ThumbUpIcon */.Z7j, {
          className: "h-5 mx-2"
        }), " ", result.vote_count]
      })]
    })]
  });
});
/* harmony default export */ const components_Thumbnail = (Thumbnail);
;// CONCATENATED MODULE: external "react-flip-move"
const external_react_flip_move_namespaceObject = require("react-flip-move");
var external_react_flip_move_default = /*#__PURE__*/__webpack_require__.n(external_react_flip_move_namespaceObject);
;// CONCATENATED MODULE: ./components/Results.js




function Results({
  results
}) {
  return /*#__PURE__*/jsx_runtime_.jsx((external_react_flip_move_default()), {
    className: "px-5 my-10 sm:grid md:grid-cols-2 xl:grid-cols-3 3xl:flex flex-wrap justify-center",
    children: results.map(result => /*#__PURE__*/jsx_runtime_.jsx(components_Thumbnail, {
      result: result
    }, result.id))
  });
}

/* harmony default export */ const components_Results = (Results);
;// CONCATENATED MODULE: ./pages/index.js







function Home({
  results
}) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Hulu - Clone"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: "Generated by create next app"
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "icon",
        href: "/favicon.ico"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(components_Header, {}), /*#__PURE__*/jsx_runtime_.jsx(components_Nav, {}), /*#__PURE__*/jsx_runtime_.jsx(components_Results, {
      results: results
    })]
  });
}
async function getServerSideProps(context) {
  var _requests$genre;

  const genre = context.query.genre;
  const request = await fetch(`https://api.themoviedb.org/3${((_requests$genre = requests[genre]) === null || _requests$genre === void 0 ? void 0 : _requests$genre.url) || requests.fetchTrending.url}`).then(res => res.json());
  return {
    props: {
      results: request.results
    }
  };
}

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [383], () => (__webpack_exec__(998)));
module.exports = __webpack_exports__;

})();